# PuTTY AI Windows x64 测试报告

测试日期：2026-07-21  
构建类型：MSVC x64 Release  
基础版本：PuTTY 0.84

## 本次修复

- AccessClient 使用 `@会话名`、`-load 会话名`、`-load tmp:UTF-8临时配置文件 -pw ...` 或 `-raw -P 本地端口` 启动时均可直接创建会话，不再打开 Configuration。
- 启动诊断会在参数解析前记录父进程、实际可执行文件路径、工作目录、完整 `GetCommandLineW()` 命令行和 WinMain 参数，便于还原 AccessClient 的真实调用方式。
- 非串口连接的应用层保活间隔限制为最多 30 秒，并启用 Windows TCP keepalive；TCP 首次探测为 30 秒，后续探测间隔为 10 秒。
- 公网 IPv4 主机输入会清理 CR/LF 等不可见空白，避免地址显示正常但解析失败。
- Chat Completions 端点、模型、上下文长度和 API Key 可编辑并永久保存，重新打开会话后可恢复并继续请求。
- 点击右侧聊天区后再点击左侧终端，会恢复终端键盘焦点。
- 系统提示词和请求包装使用中文，支持分析与纯文本回答，不要求每次输出命令。
- 当前窗口支持多轮会话，后续请求携带此前成功的用户问题和模型回答。
- 已移除知识库控件、文件读取、请求拼接和提示词残留，并清理旧版 `KnowledgeFile` 注册表值。
- Chat Completions 已开启 SSE 流式响应，首个内容分片会立即显示；完成后恢复 Markdown 排版和命令识别。
- 终端上下文默认关闭，右侧提示、状态、设置和确认文案均已中文化。
- 右侧面板常规宽度扩大到 480 像素，窄窗口下响应式收缩；Rich Edit 固定白底并显式设置回复文字颜色，避免多轮后出现白字。

## 自动化结果

- `putty` Release 构建：通过。
- `test_conf.exe`：通过；覆盖 IPv4 地址清洗、中文 UTF-8 转换和 30 秒保活策略。
- `test_terminal.exe`：通过。
- `test_lineedit.exe`：通过。
- 普通端到端回归：通过。
- 危险命令端到端回归：通过；高风险模式触发二次确认，且不会自动发送 Enter。
- 堡垒机启动：`@会话名`、`-load 会话名`、`-load tmp:临时配置文件 -pw ...` 和 `-raw -P 本地端口` 均通过真实本地连接测试，未出现 Configuration。
- Chat Completions 与 API Key 持久化：通过；关闭并重新打开会话后，恢复的配置可继续完成模型请求。
- 左右侧焦点恢复、中文提示词、纯文本回答、多轮会话和知识库移除：通过。
- 流式首段可见性、默认不传上下文、中文界面、聊天文字颜色、480 像素面板宽度和最终 Markdown 重排：通过。

## 公网连接检查

- `ssh.github.com:443`：通过 PuTTY AI 完成主机密钥协商并到达 `publickey` 认证阶段。
- `47.94.23.233:22`：通过 PuTTY AI 完成主机密钥协商，连接在认证后的 SSH 会话阶段保持打开，公网 IPv4 直连通过。

## 运行依赖

发布目录包含应用本地 `vcruntime140.dll`。其余依赖均为 Windows 10/11 系统组件，包括 WinHTTP、UCRT、User32、GDI32 和 Advapi32。

## SHA-256

具体校验值见发布包内及外层目录的 `SHA256SUMS.txt`。
